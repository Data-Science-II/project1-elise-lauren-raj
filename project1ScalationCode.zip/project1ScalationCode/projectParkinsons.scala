
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** @author  Hao Peng, John Miller
 *  @version 1.6
 *  @date    Tue Sep 29 14:14:15 EDT 2015
 *  @see     LICENSE (MIT style license file).
 *
 *  @title   Example Dataset: Automobile Miles Per Gallon (MPG)
 */

package example

import scalation.analytics._
import scalation.linalgebra.{MatrixD, VectorD, vectorD2StatVec}
import scalation.plot.Plot
import scalation.util.banner
import scalation.plot.PlotM

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** The `Concrete` object stored the UCI AutoMPG dataset in a matrix.
 *  @see archive.ics.uci.edu/ml/datasets/Auto+MPG
 */
object Parkinsons 
{

        MatrixD.setSp(',')
        val xy = MatrixD("src/main/scala/example/Parkinsons.csv") 
  /** vector of all ones
     */
    //val xy = xyz.sliceCol (1, 8)
    val _1 = VectorD.one (xy.dim1)
    /** the separation of the combine data matrix 'xy' into
     *  a data/input matrix 'x' and a response/output vector 'y'
     */
    val (x, y) = pullResponse (xy)

    /** the combined data matrix 'xy' with a column of all ones prepended
     *  for intercept models
     */
    val oxy = _1 +^: xy

    /** the data matrix 'x' with a column of all ones prepended for intercept models
     */
    val ox = _1 +^: x
	println(s"This is x" + x)
	println(s"This is y" + y)
} // Parkinsons object






import Parkinsons._

object Parkinsons_RegressionForward extends App 
{
	banner ("Regression with Forward Selection")
	val rg = Regression (oxy)
	val (cols, rSq) = rg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size 
        val t = VectorD.range (1, k) 
	new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true)
	new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	

	banner("Reg Forward")
}

object Parkinsons_RegressionBackward extends App
{
        banner ("Regression with Backward Selection")
        val rg = Regression (oxy)
        val (cols, rSq) = rg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Reg Backwards")

}

object Parkinsons_RegressionStepwise extends App
{ 
        banner ("Regression with Stepwise Selection")
        val rg = Regression (oxy)
        val (cols, rSq) = rg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
	val k = cols.size
        val t = VectorD.range (1, rSq.dim1)
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Reg Step")
        

}



object Parkinsons_QuadRegressionForward extends App
{
	banner ("Quadratic Regression with Forward Selection")
	val qrg = QuadRegression (xy)
	val (cols, rSq) = qrg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
	val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        println (s"rSq = $rSq")
	new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)	

	banner("Quad Forward")



}

object Parkinsons_Ridge extends App 
{
	banner ("Ridge Regression")
	val rrg = RidgeRegression(xy)
	println(rrg.analyze ().report)
	println(rrg.summary)
	banner("Ridge Regression")
}

object Parkinsons_QuadRidge extends App
{
        banner ("Quad Ridge Regression")
        val c = new MatrixD (x.dim1,23)
        val rrg = QuadRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Quad Ridge Regression")
}
object Parkinsons_QuadXRidge extends App
{
        banner ("QuadX Ridge Regression")
        val c = new MatrixD (x.dim1,27)
        val rrg = QuadXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("QuadX Ridge Regression")
}

object Parkinsons_CubicRidge extends App
{
        banner ("Cubic Ridge Regression")
        val c = new MatrixD (x.dim1,34)
        val rrg = CubicRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Cubic Ridge Regression")
}
object Parkinsons_CubicXRidge extends App
{

        banner ("CubicX Ridge Regression")
        val c = new MatrixD (x.dim1,84)
        val rrg = CubicXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("CubicX Ridge Regression")
}
object Parkinsons_Lasso extends App
{
        banner ("Lasso Regression")
        val lrg = LassoRegression(xy)
        println(lrg.analyze ().report)
        println(lrg.summary)
        banner("Lasso")

}

object Parkinsons_QuadLasso extends App
{
        banner ("Quad Lasso Regression")
        val numdim = x.dim2*2
        val num3 = numdim + 1
        val c = new MatrixD (x.dim1,13)
        val rrg = QuadRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Quad Lasso Regression")
}
object Parkinsons_QuadXLasso extends App
{
        banner ("QuadX Lasso Regression")
        val c = new MatrixD (x.dim1,28)
        val rrg = QuadXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("QuadX Lasso Regression")
}

object Parkinsons_CubicLasso extends App
{

        banner ("Cubic Lasso Regression")
        val c = new MatrixD (x.dim1,34)
        val rrg = CubicRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Cubic Lasso Regression")
}
object Parkinsons_CubicXLasso extends App
{
        banner ("CubicX Lasso Regression")
        val c = new MatrixD (x.dim1,84)
        val rrg = CubicXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("CubicX Lasso Regression")
}

object Parkinsons_QuadRegressionStepwise extends App 
{

 banner ("Quadratic Regression with Stepwise Selection")
	val qrg = QuadRegression (xy)
	val (cols, rSq) = qrg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
	val k = cols.size
        val t = VectorD.range (1, rSq.dim1)
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Quad Step")
}


object Parkinsons_QuadRegressionBackward extends App 
{
	banner ("Quadratic Regression with Backward Selection")
	val qrg = QuadRegression (xy)
        val (cols, rSq) = qrg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
	println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                            // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)

	banner("Quad Back")
        
}


//My own code for quadXregression

object Parkinsons_QuadXRegressionForward extends App
{

        banner ("Quadratic X Regression with Forward Selection")
        val qrg = QuadXRegression (xy)
        val (cols, rSq) = qrg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("QuadX Forward")
}

object Parkinsons_QuadXRegressionBackward extends App
{
	/* commented out for runtime convenience

        banner ("Quadratic X Regression with Backward Selection")
        val qrg = QuadXRegression (xy)
        val (cols, rSq) = qrg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("QuadX Back")
	*/
}

object Parkinsons_QuadXRegressionStepwise extends App
{

        banner ("Quadratic X Regression with Stewpise Selection")
        val qrg = QuadXRegression (xy)
        val (cols, rSq) = qrg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("QuadX Step")
}

//My own code for Cubic Regression

object Parkinsons_CubicRegressionForward extends App
{
	banner ("Cubic Regression with Forward Selection")
        val crg = CubicRegression (xy)
        val (cols, rSq) = crg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Cubic Forward")


}

object Parkinsons_CubicRegressionBackward extends App
{
	/* commented out for running convenience, uncomment if desired
        banner ("Cubic Regression with Backward Elimination")
        val crg = CubicRegression (xy)
        val (cols, rSq) = crg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Cubic Backward")

	*/
}

object Parkinsons_CubicRegressionStepwise extends App
{
	/* commented out for running convenience
        banner ("Cubic Regression with Stepwise Selection")
        val crg = CubicRegression (xy)
        val (cols, rSq) = crg.stewpiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Cubic Step")
	*/

}



//My own code for CubicX Regression

object Parkinsons_CubicXRegressionForward extends App
{

	banner ("Cubic X Regression with Forward Selection")
        val crg = CubicXRegression (xy)
        val (cols, rSq) = crg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("CubicX Forward")
} 

object Parkinsons_CubicXRegressionBackward extends App
{

	/* commented out for runtime convenience
        banner ("Cubic X Regression with Backward Selection")
        val crg = CubicXRegression (xy)
        val (cols, rSq) = crg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("CubicX Backward")
	*/
	
} 

object Parkinsons_CubicXRegressionStepwise extends App
{

        banner ("Cubic X Regression with Stepwise Selection")
        val crg = CubicXRegression (xy)
        val (cols, rSq) = crg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
	new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("CubicX Step")
} 

