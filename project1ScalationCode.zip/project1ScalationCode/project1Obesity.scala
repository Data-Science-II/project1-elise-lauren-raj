
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** @author  Lauren Rose Wilkes
 *  @version 1.6
 *  @date    February 25
 *  @see     LICENSE (MIT style license file).
 *
 *  @title   Example Dataset: Obesity
 */

package example

import scalation.analytics._
import scalation.linalgebra.{MatrixD, VectorD, vectorD2StatVec}
import scalation.plot.Plot
import scalation.util.banner
import scalation.plot.PlotM

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
/** The `Obesity` object stored the UCI AutoMPG dataset in a csv.
 *  @see archive.ics.uci.edu/ml/datasets/Auto+MPG
 */
object Obesity 
{

        MatrixD.setSp(',')
        val xy = MatrixD("src/main/scala/example/Obesity.csv") 
  /** vector of all ones
     */
    //val xy = xyz.sliceCol (1, 8)
    val _1 = VectorD.one (xy.dim1)
    /** the separation of the combine data matrix 'xy' into
     *  a data/input matrix 'x' and a response/output vector 'y'
     */
    val (x, y) = pullResponse (xy)

    /** the combined data matrix 'xy' with a column of all ones prepended
     *  for intercept models
     */
    val oxy = _1 +^: xy

    /** the data matrix 'x' with a column of all ones prepended for intercept models
     */
    val ox = _1 +^: x
	println(s"This is x" + x)
	println(s"This is y" + y)
} // Obesity object






import Obesity._
/** This performs forward selection on the regression model and plots r squared and aic values.
 */

object Obesity_RegressionForward extends App 
{
	banner ("Regression with Forward Selection")
	val rg = Regression (oxy)
	val (cols, rSq) = rg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size 
        val t = VectorD.range (1, k) 
	new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true)
	new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	

	banner("Reg Forward")
}
/** This performs backward on the quadratic regression model and plots r squared and aic values.
 */
object Obesity_RegressionBackward extends App
{
        banner ("Regression with Backward Selection")
        val rg = Regression (oxy)
        val (cols, rSq) = rg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Reg Backwards")

}
/** This performs stepwise selection on the quadratic regression model and plots r squared and aic values.
 */

object Obesity_RegressionStepwise extends App
{ 
        banner ("Regression with Stepwise Selection")
        val rg = Regression (oxy)
        val (cols, rSq) = rg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
	val k = cols.size
        val t = VectorD.range (1, rSq.dim1)
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Reg Step")
        

}

/** This performs forward selection on the quadratic regression model and plots r squared and aic values.
 */

object Obesity_QuadRegressionForward extends App
{
	banner ("Quadratic Regression with Forward Selection")
	val qrg = QuadRegression (xy)
	val (cols, rSq) = qrg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
	val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        println (s"rSq = $rSq")
	new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)	

	banner("Quad Forward")



}
/** This performs ridge on the regression model and prints summary model output.
 */


object Obesity_Ridge extends App 
{
	banner ("Ridge Regression")
	val rrg = RidgeRegression(xy)
	println(rrg.analyze ().report)
	println(rrg.summary)
	banner("Ridge Regression")
}

/** This performs ridge on the quadratic regression model and prints summary model output.
 */
object Obesity_QuadRidge extends App
{
        banner ("Quad Ridge Regression")
        val c = new MatrixD (x.dim1,12)
        val rrg = QuadRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Quad Ridge Regression")
}

/** This performs ridge on the quadraticX model and prints summary model output.
 */
object Obesity_QuadXRidge extends App
{
        banner ("QuadX Ridge Regression")
        val c = new MatrixD (x.dim1,27)
        val rrg = QuadXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("QuadX Ridge Regression")
}

/** This performs ridge on the cubic regression model and prints summary model output.
 */

object Obesity_CubicRidge extends App
{
        banner ("Cubic Ridge Regression")
        val c = new MatrixD (x.dim1,34)
        val rrg = CubicRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Cubic Ridge Regression")
}

/** This performs ridge on the cubicX model and prints summary model output.
 */
object Obesity_CubicXRidge extends App
{

        banner ("CubicX Ridge Regression")
        val c = new MatrixD (x.dim1,84)
        val rrg = CubicXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = RidgeRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("CubicX Ridge Regression")
}

/** This performs lasso on the regression model and prints summary model output.
 */
object Obesity_Lasso extends App
{
        banner ("Lasso Regression")
        val lrg = LassoRegression(xy)
        println(lrg.analyze ().report)
        println(lrg.summary)
        banner("Lasso")

}

/** This performs lasso on the quadratic regression model and prints summary model output.
 */
object Obesity_QuadLasso extends App
{
        banner ("Quad Lasso Regression")
        val numdim = x.dim2*2
        val num3 = numdim + 1
        val c = new MatrixD (x.dim1,13)
        val rrg = QuadRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Quad Lasso Regression")
}

/** This performs lasso on the quadraticX regression model and prints summary model output.
 */
object Obesity_QuadXLasso extends App
{
        banner ("QuadX Lasso Regression")
        val c = new MatrixD (x.dim1,28)
        val rrg = QuadXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("QuadX Lasso Regression")
}
/** This performs lasso on the cubic regression model and prints summary model output.
 */
object Obesity_CubicLasso extends App
{

        banner ("Cubic Lasso Regression")
        val c = new MatrixD (x.dim1,34)
        val rrg = CubicRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("Cubic Lasso Regression")
}

/** This performs lasso on the cubicX regression model and prints summary model output.
 */
object Obesity_CubicXLasso extends App
{
        banner ("CubicX Lasso Regression")
        val c = new MatrixD (x.dim1,84)
        val rrg = CubicXRegression(xy)
        val num = x.dim1
        for (l <- 0 until x.dim1 - 1) {
        val newVect = VectorD(1,x.dim1)
        if (1 == 1) {
        c(l) = rrg.expand(x(l))
        }
        }
        val newc = y +: c
        val newqrg = LassoRegression(c)
        println(newqrg.analyze ().report)
        println(newqrg.summary)
        banner("CubicX Lasso Regression")
}

/** This performs stepwise selection on the quadratic regression model and plots r squared and aic values.
 */
object Obesity_QuadRegressionStepwise extends App 
{

 banner ("Quadratic Regression with Stepwise Selection")
	val qrg = QuadRegression (xy)
	val (cols, rSq) = qrg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
	val k = cols.size
        val t = VectorD.range (1, rSq.dim1)
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Quad Step")
}

/** This performs backward elinimation on the quadratic regression model and plots r squared and aic values.
 */
object Obesity_QuadRegressionBackward extends App 
{
	banner ("Quadratic Regression with Backward Selection")
	val qrg = QuadRegression (xy)
        val (cols, rSq) = qrg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
	println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                            // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)

	banner("Quad Back")
        
}


//My own code for quadXregression
/** This performs forward selection on the quadraticX regression model and plots r squared and aic values.
 */
object Obesity_QuadXRegressionForward extends App
{

        banner ("Quadratic X Regression with Forward Selection")
        val qrg = QuadXRegression (xy)
        val (cols, rSq) = qrg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("QuadX Forward")
}
/** This performs backward elinimation on the quadraticX regression model and plots r squared and aic values.
 */
object Obesity_QuadXRegressionBackward extends App
{

        banner ("Quadratic X Regression with Backward Selection")
        val qrg = QuadXRegression (xy)
        val (cols, rSq) = qrg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("QuadX Back")
}

/** This performs stepwise selection on the quadraticX regression model and plots r squared and aic values.
 */
object Obesity_QuadXRegressionStepwise extends App
{

        banner ("Quadratic X Regression with Stewpise Selection")
        val qrg = QuadXRegression (xy)
        val (cols, rSq) = qrg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("QuadX Step")
}

//My own code for Cubic Regression
/** This performs forward selection on the cubic regression model and plots r squared and aic values.
 */
object Obesity_CubicRegressionForward extends App
{
	banner ("Cubic Regression with Forward Selection")
        val crg = CubicRegression (xy)
        val (cols, rSq) = crg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Cubic Forward")


}
/** This performs backward elinimation on the cubic regression model and plots r squared and aic values.
 */
object Obesity_CubicRegressionBackward extends App
{
        banner ("Cubic Regression with Backward Elimination")
        val crg = CubicRegression (xy)
        val (cols, rSq) = crg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Cubic Backward")


}
/** This performs stepwise selection on the cubic regression model and plots r squared and aic values.
 */
object Obesity_CubicRegressionStepwise extends App
{
	/* commented out for convenience during runtime
        banner ("Cubic Regression with Stepwise Selection")
        val crg = CubicRegression (xy)
        val (cols, rSq) = crg.stewpiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("Cubic Step")

	*/
}



//My own code for CubicX Regression
/** This performs forward selection on the cubicX regression model and plots r squared and aic values.
 */
object Obesity_CubicXRegressionForward extends App
{

	banner ("Cubic X Regression with Forward Selection")
        val crg = CubicXRegression (xy)
        val (cols, rSq) = crg.forwardSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, k)                                     // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("CubicX Forward")
} 

/** This performs backward elinimation on the cubicX regression model and plots r squared and aic values.
 */
object Obesity_CubicXRegressionBackward extends App
{

        banner ("Cubic X Regression with Backward Selection")
        val crg = CubicXRegression (xy)
        val (cols, rSq) = crg.backwardElimAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
        new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("CubicX Backward")
} 

/** This performs stepwise selection on the cubicX regression model and plots r squared and aic values.
 */

object Obesity_CubicXRegressionStepwise extends App
{

        banner ("Cubic X Regression with Stepwise Selection")
        val crg = CubicXRegression (xy)
        val (cols, rSq) = crg.stepwiseSelAll ()                           // R^2, R^2 bar, R^2 cv
        println(s"rSq = $rSq")
        val k = cols.size
        val t = VectorD.range (1, rSq.dim1)                              // instance index
	new PlotM (t, rSq.selectCols(Array(0,1,2)).t, Array ("R^2", "R^2 bar", "R^2 cv"),
               "R^2 vs n for Regression", lines = true) 
        new PlotM (t, rSq.selectCols(Array(3)).t, Array ("AIC"),
               "AIC vs n for Regression", lines = true)
	banner("CubicX Step")
} 

